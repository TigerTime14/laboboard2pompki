/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    can.h
  * @brief   This file contains all the function prototypes for
  *          the can.c file
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __POMP_H__
#define __POMP_H__

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* USER CODE BEGIN Includes */

/* USER CODE END Includes */


/* USER CODE BEGIN Private defines */
typedef	enum Pomp{
	POMP_1 = 0,
	POMP_2 = 1,
	POMP_3 = 2,
	POMP_4 = 3,
	POMP_5 = 4,
} Pomp;
/* USER CODE END Private defines */

/* USER CODE BEGIN Prototypes */
void	pomp_switch(Pomp pomps);
/* USER CODE END Prototypes */

#ifdef __cplusplus
}
#endif

#endif /* __POMP_H__ */

